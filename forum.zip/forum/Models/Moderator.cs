﻿using System.ComponentModel.DataAnnotations;
namespace forum.Models
{
    public class Moderator  :User
    {
    }
}
